(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 9273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const Circle = ({
  top,
  left,
  bottom,
  right,
  backgroundColor
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    style: {
      top,
      left,
      bottom,
      right,
      backgroundColor
    },
    className: "circle"
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Circle);

/***/ }),

/***/ 9890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./styles/Intro.module.css
var Intro_module = __webpack_require__(3977);
var Intro_module_default = /*#__PURE__*/__webpack_require__.n(Intro_module);
// EXTERNAL MODULE: ./components/Circle.jsx
var components_Circle = __webpack_require__(9273);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Intro.js







const Intro = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Intro_module_default()).container,
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Circle/* default */.Z, {
      backgroundColor: "#01c686",
      top: "-45vh",
      left: "-45vh"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Intro_module_default()).card,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: (Intro_module_default()).title,
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: (Intro_module_default()).brandName,
          children: "Offshore Account"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: (Intro_module_default()).desc,
        children: "Expand your business worldwide Get your business account within minutes and manage your financials with ease."
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: (Intro_module_default()).button,
        children: [" ", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/login",
          children: " Login to your Account "
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Intro_module_default()).card,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "https://anchor-offshore.com" + "/banner.jpg",
        layout: "fill",
        objectFit: "cover",
        alt: ""
      })
    })]
  });
};

/* harmony default export */ const components_Intro = (Intro);
;// CONCATENATED MODULE: ./components/Services.jsx






const Services = ({
  services
}) => {
  return /*#__PURE__*/_jsx("div", {
    className: style.container,
    children: /*#__PURE__*/_jsxs("div", {
      className: style.info,
      children: [/*#__PURE__*/_jsx("h1", {
        className: style.title,
        children: "What We Can Do?"
      }), /*#__PURE__*/_jsx("h1", {
        className: style.subtitle,
        children: "Services we can help you with"
      }), /*#__PURE__*/_jsx("div", {
        className: style.services,
        children: services.map(service => /*#__PURE__*/_jsx(Link, {
          href: `/products/${service.name}`,
          passHref: true,
          children: /*#__PURE__*/_jsxs("div", {
            className: style.service,
            children: [/*#__PURE__*/_jsx("div", {
              className: style.catInfo,
              children: service.desc
            }), /*#__PURE__*/_jsx("span", {
              className: style.cat,
              children: service.title
            }), /*#__PURE__*/_jsx("div", {
              className: style.media,
              children: service.video ? /*#__PURE__*/_jsx("video", {
                className: style.video,
                src: `/img/${service.video}`,
                autoPlay: true,
                loop: true
              }) : /*#__PURE__*/_jsx(Image, {
                src: `${"https://anchor-offshore.com"}/img/${service.photo}`,
                width: "100%",
                height: "100%",
                layout: "responsive",
                objectFit: "cover",
                alt: ""
              })
            })]
          })
        }, service.id))
      })]
    })
  });
};

/* harmony default export */ const components_Services = ((/* unused pure expression or super */ null && (Services)));
// EXTERNAL MODULE: ./data.js
var data = __webpack_require__(9459);
;// CONCATENATED MODULE: ./components/Testimonials.jsx







const Testimonials = () => {
  return /*#__PURE__*/_jsxs("div", {
    className: style.container,
    children: [/*#__PURE__*/_jsx(Circle, {
      top: "-70vh",
      left: "0",
      right: "0",
      backgroundColor: "darkblue"
    }), /*#__PURE__*/_jsx("h1", {
      className: style.title,
      children: "Testimonials"
    }), /*#__PURE__*/_jsx("div", {
      className: style.wrapper,
      children: users.map(user => /*#__PURE__*/_jsxs("div", {
        className: style.card,
        children: [/*#__PURE__*/_jsx(Image, {
          src: `${"https://anchor-offshore.com"}/img/${user.logo}`,
          width: "30",
          height: "30",
          alt: ""
        }), /*#__PURE__*/_jsxs("p", {
          className: style.comment,
          children: ["\u201C", user.comment, "\u201D"]
        }), /*#__PURE__*/_jsxs("div", {
          className: style.person,
          children: [/*#__PURE__*/_jsx(Image, {
            className: style.avatar,
            src: `${"https://anchor-offshore.com"}/img/${user.avatar}`,
            width: "45",
            height: "45",
            objectFit: "cover",
            alt: ""
          }), /*#__PURE__*/_jsxs("div", {
            className: style.info,
            children: [/*#__PURE__*/_jsx("span", {
              className: style.username,
              children: user.name
            }), /*#__PURE__*/_jsx("span", {
              className: style.jobTitle,
              children: user.title
            })]
          })]
        })]
      }, user.id))
    })]
  });
};

/* harmony default export */ const components_Testimonials = ((/* unused pure expression or super */ null && (Testimonials)));
;// CONCATENATED MODULE: ./pages/index.js









function Home({
  services
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Anchor Offshore"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "banking, business account, offshore account"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(components_Intro, {})]
  });
}
const getStaticProps = () => {
  const services = data/* data */.a;
  return {
    props: {
      services
    }
  };
};

/***/ }),

/***/ 3977:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Intro_container__DxB0T",
	"card": "Intro_card__1pb0r",
	"circle": "Intro_circle__yvGax",
	"circle1": "Intro_circle1__3cSpd",
	"circle2": "Intro_circle2__xroKa",
	"title": "Intro_title__3SLtm",
	"brandName": "Intro_brandName__23hXs",
	"desc": "Intro_desc__17IpG",
	"button": "Intro_button__1kB4P"
};


/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,5675,2636], () => (__webpack_exec__(9890)));
module.exports = __webpack_exports__;

})();