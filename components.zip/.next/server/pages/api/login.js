"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 9689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ login)
});

// EXTERNAL MODULE: external "next-connect"
var external_next_connect_ = __webpack_require__(9303);
var external_next_connect_default = /*#__PURE__*/__webpack_require__.n(external_next_connect_);
// EXTERNAL MODULE: ./common/errormiddleware.js
var errormiddleware = __webpack_require__(9773);
// EXTERNAL MODULE: ./config/db.js
var db = __webpack_require__(8111);
// EXTERNAL MODULE: ./common/errorHandler.js
var errorHandler = __webpack_require__(1159);
;// CONCATENATED MODULE: ./controller/login/login.js



const getUserByEmailAndPass = async (req, res, next) => {
  try {
    var email = req.body.email;
    var password = req.body.password;

    if (!email) {
      res.status(400).json(error.details[0].message);
    } else {
      console.log("search user with email and password");
      let UserData = await (0,db/* default */.Z)({
        query: 'select * from users where email=(?) && password=(?)',
        values: [email, password]
      });

      if (UserData.length > 0) {
        var result = {
          "error": false,
          "mess": "user found",
          "user": UserData
        };
        res.status(200).json(result);
      } else {
        var result = {
          "error": true,
          "mess": "user not found"
        };
        res.status(211).json(result);
      }

      var result = {
        "error": true,
        "mess": "error in query"
      };
      res.status(215).json(result);
    }
  } catch (err) {
    console.error(err);
    res.status(400).json(err);
  }
};


;// CONCATENATED MODULE: ./pages/api/login/index.js



const handler = external_next_connect_default()(errormiddleware/* default */.Z);
handler.post(getUserByEmailAndPass);
/* harmony default export */ const login = (handler);

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9923], () => (__webpack_exec__(9689)));
module.exports = __webpack_exports__;

})();