"use strict";
(() => {
var exports = {};
exports.id = 1421;
exports.ids = [1421];
exports.modules = {

/***/ 2554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_)
});

// EXTERNAL MODULE: external "next-connect"
var external_next_connect_ = __webpack_require__(9303);
var external_next_connect_default = /*#__PURE__*/__webpack_require__.n(external_next_connect_);
// EXTERNAL MODULE: ./common/errormiddleware.js
var errormiddleware = __webpack_require__(9773);
// EXTERNAL MODULE: ./config/db.js
var db = __webpack_require__(8111);
// EXTERNAL MODULE: ./common/errorHandler.js
var errorHandler = __webpack_require__(1159);
;// CONCATENATED MODULE: ./controller/transaction/tranxbyid.js



const getTransactionById = async (req, res, next) => {
  let id = req.query.id;
  let tstatus = "blocked";

  try {
    console.log("Transaction by Cus id");
    let CustomerData = await (0,db/* default */.Z)({
      query: 'SELECT * FROM transaction where cus_id=? AND transaction_status!=?',
      values: [id, tstatus]
    });
    console.log(CustomerData);

    if (CustomerData.length > 0) {
      var result = {
        "error": false,
        "mess": "Customer found",
        "transaction": CustomerData
      };
      console.log(result);
      res.status(200).json(result);
    } else {
      next(new errorHandler/* default */.Z(`no Customer found with this id ${id}`, 404));
    }
  } catch (err) {
    res.status(500).json(err);
  }
};


;// CONCATENATED MODULE: ./pages/api/transbycusid/[id].js



const handler = external_next_connect_default()({
  onError: errormiddleware/* default */.Z
});
handler.get(getTransactionById);
/* harmony default export */ const _id_ = (handler);

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9923], () => (__webpack_exec__(2554)));
module.exports = __webpack_exports__;

})();