"use strict";
(() => {
var exports = {};
exports.id = 7959;
exports.ids = [7959];
exports.modules = {

/***/ 3385:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ dtransaction)
});

// EXTERNAL MODULE: external "next-connect"
var external_next_connect_ = __webpack_require__(9303);
var external_next_connect_default = /*#__PURE__*/__webpack_require__.n(external_next_connect_);
// EXTERNAL MODULE: ./common/errormiddleware.js
var errormiddleware = __webpack_require__(9773);
// EXTERNAL MODULE: ./config/db.js
var db = __webpack_require__(8111);
// EXTERNAL MODULE: ./common/errorHandler.js
var errorHandler = __webpack_require__(1159);
;// CONCATENATED MODULE: ./controller/dtransaction/tranx.js



const getAllCustomers = async (req, res) => {
  try {
    console.log("all the Transactions"); //let CustomerData = await executeQuery("select * from Customer");

    const CustomerData = await (0,db/* default */.Z)({
      query: 'SELECT * FROM transaction'
    });
    console.log(CustomerData);
    res.status(201).json(CustomerData);
  } catch (err) {
    console.error(err);
    res.status(500).json(err);
  }
}; // SELECT COUNT(trans_id) FROM transaction


const getCustomerById = async (req, res, next) => {
  let id = req.query.id;

  try {
    console.log("Customer by id");
    let CustomerData = await executeQuery({
      query: 'SELECT * FROM transaction where trans_id=?',
      values: [id]
    });
    console.log(CustomerData);

    if (CustomerData.length > 0) {
      var result = {
        "error": false,
        "mess": "Customer found",
        "transaction": CustomerData
      };
      console.log(result);
      res.status(200).json(result);
    } else {
      next(new ErrorHandler(`no Customer found with this id ${id}`, 404));
    }
  } catch (err) {
    res.status(500).json(err);
  }
};

const deleteCustomerById = async (req, res, next) => {
  let id = req.query.id;

  try {
    let CustomerData = await executeQuery("delete from customer where Customer_id=?", [id]); // if (CustomerData.length > 0) res.status(200).json('Customer');
    // else {
    //   next(
    //     new ErrorHandler(` Customer  doesnt exist in db with id ${id}`, 404)
    //   );
    // }

    res.status(200).json("Customer Deleted Successfully");
  } catch (err) {
    res.status(500).json(err);
  }
};

const saveTransaction = async (req, res) => {
  try {
    var name = req.body.name;
    var address = "admin post";
    var clientAccount = "0900000000";
    var clientFund = parseInt(req.body.amount);
    var cus_id = req.body.cus_id;
    var ibanNumber = "00000000";
    var ifund = parseInt(req.body.iamount);
    var description = req.body.desc;
    var cdate = req.body.cdate;
    var trans_status = "successful";
    var balance = ifund - clientFund;

    if (balance < 0) {
      res.status(400).json(error.details[0].message);
    } else {
      console.log("post request");
      let CustomerData = await (0,db/* default */.Z)({
        query: 'insert into transaction (cus_id,name,amount,iban_number, trans_date,acct_number, address, description, transaction_status) values(?,?,?,?,?,?,?,?,?)',
        values: [cus_id, name, clientFund, ibanNumber, cdate, clientAccount, address, description, trans_status]
      });

      if (CustomerData) {
        CustomerData = await (0,db/* default */.Z)({
          query: "update customer set amount=? where cus_id=?",
          values: [balance, cus_id]
        });
        res.status(200).json(CustomerData);
      } else {
        res.status(400).json(`Record not found on this id=${cus_id}`);
      }
    }
  } catch (err) {
    //console.error(err);
    res.status(400).json(err);
  }
};

const updateCustomer = async (req, res) => {
  console.log("update single Transaction");
  var trans_id = req.body.trans_id;
  var name = req.body.name;
  var anumber = req.body.acct_number;
  var inumber = req.body.iban_number;
  var address = req.body.address;

  try {
    let CustomerData = await executeQuery({
      query: "select * from transaction where trans_id=?",
      values: [trans_id]
    });

    if (CustomerData.length > 0) {
      CustomerData = await executeQuery({
        query: "update transaction set name=?, acct_number=?, iban_number =?, address=? where trans_id=?",
        values: [name, anumber, inumber, address, trans_id]
      });
      res.status(200).json(CustomerData);
    } else {
      res.status(400).json(`Record not found on this id=${trans_id}`);
    }
  } catch (err) {
    console.log(err);
    res.status(400).json(err);
  }
};


;// CONCATENATED MODULE: ./pages/api/dtransaction/index.js



const handler = external_next_connect_default()(errormiddleware/* default */.Z);
handler.get(getAllCustomers);
handler.post(saveTransaction);
/* harmony default export */ const dtransaction = (handler);

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9923], () => (__webpack_exec__(3385)));
module.exports = __webpack_exports__;

})();