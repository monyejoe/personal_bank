"use strict";
(() => {
var exports = {};
exports.id = 9617;
exports.ids = [9617];
exports.modules = {

/***/ 8086:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9303);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_errormiddleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9773);
/* harmony import */ var _controller_msg_msg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8561);



const handler = next_connect__WEBPACK_IMPORTED_MODULE_0___default()({
  onError: _common_errormiddleware__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z
});
handler.get(_controller_msg_msg__WEBPACK_IMPORTED_MODULE_1__/* .getMsgById */ .y9);
handler.delete(_controller_msg_msg__WEBPACK_IMPORTED_MODULE_1__/* .deleteUserById */ .JS);
handler.put(_controller_msg_msg__WEBPACK_IMPORTED_MODULE_1__/* .updateMsg */ .Yd);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9923,8561], () => (__webpack_exec__(8086)));
module.exports = __webpack_exports__;

})();