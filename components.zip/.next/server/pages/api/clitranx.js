"use strict";
(() => {
var exports = {};
exports.id = 6232;
exports.ids = [6232];
exports.modules = {

/***/ 9756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9303);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_errormiddleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9773);
/* harmony import */ var _controller_transaction_tranx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5324);



const handler = next_connect__WEBPACK_IMPORTED_MODULE_0___default()(_common_errormiddleware__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z);
handler.get(_controller_transaction_tranx__WEBPACK_IMPORTED_MODULE_1__/* .getAllCustomers */ .JL);
handler.post(_controller_transaction_tranx__WEBPACK_IMPORTED_MODULE_1__/* .saveCustomer */ .I4);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 202:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9923,5324], () => (__webpack_exec__(9756)));
module.exports = __webpack_exports__;

})();