(() => {
var exports = {};
exports.id = 4492;
exports.ids = [4492];
exports.modules = {

/***/ 9273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const Circle = ({
  top,
  left,
  bottom,
  right,
  backgroundColor
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    style: {
      top,
      left,
      bottom,
      right,
      backgroundColor
    },
    className: "circle"
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Circle);

/***/ }),

/***/ 3913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Circle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9273);
/* harmony import */ var _styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1605);
/* harmony import */ var _styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_AdminNav__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7964);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function debitClient(props) {
  const {
    0: fname,
    1: setFname
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: lname,
    1: setLname
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: account,
    1: setAccount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: tamount,
    1: setTamount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: tdate,
    1: setTdate
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: cdate,
    1: setCdate
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: cid,
    1: setCid
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const fetchData = async () => {
      const res = await fetch("https://anchor-offshore.com" + `/api/customer/${props.id}`);
      const user = await res.json();
      console.log(user.customer[0]);
      setLname(user.customer[0].cus_last_name);
      setFname(user.customer[0].cus_first_name);
      setAccount(user.customer[0].cus_account);
      setTamount(user.customer[0].amount);
      setTdate(user.customer[0].date_created);
      setCid(user.customer[0].cus_id);
      return {
        props: {
          user
        }
      };
    };

    fetchData();
  }, []);
  const {
    handleSubmit,
    register,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();

  const onSubmit = async data => {
    var transaction = [];
    transaction = {
      'cus_id': cid,
      'name': lname + '' + fname,
      'amount': data.credit,
      'iamount': tamount,
      'cdate': data.cdate,
      'desc': data.desc
    };
    let result = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("https://anchor-offshore.com" + `/api/dtransaction`, transaction);

    if (result) {
      router.push('/admin/adminPage');
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_AdminNav__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().container),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_Circle__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        backgroundColor: "green",
        left: "-40vh",
        top: "-20vh",
        className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().circle)
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_Circle__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        backgroundColor: "yellow",
        right: "-30vh",
        bottom: "-60vh",
        className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().circle)
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("h1", {
        className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().title),
        children: "Credit Client"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("form", {
        className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().form),
        onSubmit: handleSubmit(onSubmit),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          type: "text",
          name: "lname",
          value: lname,
          disabled: "true"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          type: "text",
          name: "fname",
          value: fname,
          disabled: "true"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          value: "Balance",
          disabled: "true"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          type: "text",
          name: "tamount",
          value: tamount,
          disabled: "true"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          value: "Credit Amount",
          disabled: "true"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", _objectSpread({
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          type: "text",
          name: "credit"
        }, register('credit', {
          required: true
        }))), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", _objectSpread({
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().inputS),
          type: "text",
          name: "cdate"
        }, register('cdate', {
          required: true
        }))), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("textarea", _objectSpread(_objectSpread({
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().textArea),
          type: "text",
          name: "desc",
          rows: 2
        }, register('desc', {
          required: true
        })), {}, {
          placeholder: "Description"
        })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("button", {
          className: (_styles_Credit_module_css__WEBPACK_IMPORTED_MODULE_7___default().button),
          type: "submit",
          children: "DEBIT"
        })]
      })]
    })]
  });
}

const getServerSideProps = context => {
  console.log('id is ' + context.query.id);
  var user_id = context.query.id;
  return {
    props: {
      id: user_id
    }
  };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (debitClient);

/***/ }),

/***/ 1605:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Credit_container__2wmr-",
	"form": "Credit_form__e71KC",
	"inputS": "Credit_inputS__PejVk",
	"inputSI": "Credit_inputSI__2aPqn",
	"inputSL": "Credit_inputSL__KoYcY",
	"inputL": "Credit_inputL__3aX4N",
	"textArea": "Credit_textArea__3Y6X-",
	"button": "Credit_button__1rxWe"
};


/***/ }),

/***/ 2376:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 2662:
/***/ ((module) => {

"use strict";
module.exports = require("react-hook-form");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,4470], () => (__webpack_exec__(3913)));
module.exports = __webpack_exports__;

})();