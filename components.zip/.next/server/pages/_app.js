(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 6853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./styles/Layout.module.css
var Layout_module = __webpack_require__(5667);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
// EXTERNAL MODULE: ./styles/Footer.module.css
var Footer_module = __webpack_require__(2202);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Footer.js







const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Footer_module_default()).container,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Footer_module_default()).cardL,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
        className: (Footer_module_default()).title,
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "https://anchor-offshore.com" + "/img/footer-logo.png",
          width: "250",
          height: "80",
          alt: "ANCHOR BANK"
        }), " "]
      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: (Footer_module_default()).linkTitle,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/login",
          className: (Footer_module_default()).link,
          passHref: true,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: (Footer_module_default()).linkText,
              children: "BANK WITH US"
            }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: "https://anchor-offshore.com" + "/img/link.png",
              width: "40px",
              height: "40px",
              alt: ""
            })]
          })
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Footer_module_default()).cardS,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).cardItem,
        children: [/*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {})]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).cardItem,
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: (Footer_module_default()).linkText,
          children: "CONTACT US"
        }), " ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "support@anchor-offshore.com", /*#__PURE__*/jsx_runtime_.jsx("br", {})]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Footer_module_default()).cardS,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Footer_module_default()).cardItem
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).cardItem,
        children: ["\xA9 2022 ANCHOR BANK,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "ALL RIGHTS RESERVED"]
      })]
    })]
  });
};

/* harmony default export */ const components_Footer = (Footer);
// EXTERNAL MODULE: ./styles/Navbar.module.css
var Navbar_module = __webpack_require__(4643);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
;// CONCATENATED MODULE: ./components/Navbar.js







const Navbar = () => {
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Navbar_module_default()).container,
    children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "https://anchor-offshore.com" + "/img/footer-logo.png",
        width: "160",
        height: "50",
        alt: "ANCHOR BANK"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      className: (Navbar_module_default()).list,
      children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).listItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/products_services",
          children: "Products and Services"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).listItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/ways_to_bank",
          children: "Ways to bank"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).listItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/contact",
          children: "Contact us"
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Navbar_module_default()).hamburger,
      onClick: () => setOpen(!open),
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Navbar_module_default()).line
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Navbar_module_default()).line
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Navbar_module_default()).line
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      onClick: () => setOpen(false),
      className: (Navbar_module_default()).menu,
      style: {
        right: open ? "0px" : "-50vw"
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).menuItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: "HOME"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).menuItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/products_services",
          children: "Products and Services"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).listItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/ways_to_bank",
          children: "Ways to bank"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (Navbar_module_default()).menuItem,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/contact",
          children: "Contact us"
        })
      })]
    })]
  });
};

/* harmony default export */ const components_Navbar = (Navbar);
;// CONCATENATED MODULE: ./components/Layout.js







const Layout = ({
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (Layout_module_default()).container,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(components_Navbar, {}), children, /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
    })
  });
};

/* harmony default export */ const components_Layout = (Layout);
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









function MyApp({
  Component,
  pageProps
}) {
  (0,external_react_.useEffect)(() => {
    __webpack_require__(3753);
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(components_Layout, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 2202:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Footer_container__2XN74",
	"title": "Footer_title__8WFkX",
	"linkTitle": "Footer_linkTitle__j0f5C",
	"link": "Footer_link__2Anw_",
	"linkText": "Footer_linkText__2JF0e",
	"cardL": "Footer_cardL__Ir45r",
	"cardS": "Footer_cardS__39wgi",
	"cardItem": "Footer_cardItem__tIrL2"
};


/***/ }),

/***/ 5667:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Layout_container__1SPwL"
};


/***/ }),

/***/ 4643:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Navbar_container__Wwf_G",
	"listItem": "Navbar_listItem__1riT8",
	"hamburger": "Navbar_hamburger__2wKdm",
	"line": "Navbar_line__3Ywhe",
	"menu": "Navbar_menu__1xprr"
};


/***/ }),

/***/ 3753:
/***/ ((module) => {

"use strict";
module.exports = require("bootstrap/dist/js/bootstrap.bundle.min.js");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,5675], () => (__webpack_exec__(6853)));
module.exports = __webpack_exports__;

})();