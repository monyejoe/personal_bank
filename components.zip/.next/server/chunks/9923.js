"use strict";
exports.id = 9923;
exports.ids = [9923];
exports.modules = {

/***/ 1159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
class ErrorHandler extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    Error.captureStackTrace(this, this.constructor);
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorHandler);

/***/ }),

/***/ 9773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const middleware = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;

  let error = _objectSpread({}, err);

  error.message = err.message;
  res.status(err.statusCode).json({
    error,
    message: error.message,
    stack: error.stack
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (middleware);

/***/ }),

/***/ 8111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(202);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
  // config: {
  //   host: "localhost",
  //   user: "root",
  //   password: "",
  //   port: 3306,
  //   database: "bank_app",
  // }
  config: {
    host: "localhost",
    user: "anchorof_app",
    password: "Ogorfemi@123",
    port: 3306,
    database: "anchorof_anchor"
  }
});
async function executeQuery({
  query,
  values
}) {
  try {
    const results = await db.query(query, values);
    await db.end();
    return results;
  } catch (error) {
    return {
      error
    };
  }
} // const { createPool } = require('mysql');
// const pool = createPool({
//     host: "localhost",
//     user: "root",
//     password: "",
//     port: 3306,
//     database: "bank_app",
// });
// pool.getConnection((err) => {
//     if (err) {
//         console.log("Error connecting to db...");
//     }
//     console.log("Connected to db...");
// });
// const executeQuary = (query, arraParams) => {
//     return new Promise((resolve, reject) => {
//         try {
//             pool.query(query, arraParams, (err, data) => {
//                 if (err) {
//                     console.log("error in executing the query");
//                     reject(err);
//                 }
//                 resolve(data);
//             });
//         } catch (err) {
//             reject(err);
//         }
//     });
// };
// module.exports = {executeQuary};

/***/ })

};
;