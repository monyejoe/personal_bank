"use strict";
exports.id = 8561;
exports.ids = [8561];
exports.modules = {

/***/ 8561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AW": () => (/* binding */ getAllUsers),
/* harmony export */   "y9": () => (/* binding */ getMsgById),
/* harmony export */   "JS": () => (/* binding */ deleteUserById),
/* harmony export */   "KP": () => (/* binding */ saveMsg),
/* harmony export */   "Yd": () => (/* binding */ updateMsg)
/* harmony export */ });
/* harmony import */ var _config_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8111);
/* harmony import */ var _common_errorHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1159);



const getAllUsers = async (req, res) => {
  try {
    console.log("all the users"); //let UserData = await executeQuery("select * from user");

    const UserData = await (0,_config_db__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)({
      query: 'SELECT * FROM users'
    });
    console.log(UserData);
    res.status(201).json(UserData);
  } catch (err) {
    console.error(err);
    res.status(500).json(err);
  }
};

const getMsgById = async (req, res, next) => {
  let id = req.query.id;
  console.log(id);

  try {
    console.log("Message by id");
    let MsgData = await (0,_config_db__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)({
      query: 'SELECT message FROM transmsg WHERE id=?',
      values: [id]
    });

    if (MsgData.length > 0) {
      var result = {
        "error": false,
        "mess": "msg found",
        "msg": MsgData
      };
      console.log(result);
      res.status(200).json(result);
    } else {
      next(new _common_errorHandler__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z(`no Message found with this id ${id}`, 404));
    }
  } catch (err) {
    res.status(500).json(err);
  }
};

const deleteUserById = async (req, res, next) => {
  let id = req.query.id;

  try {
    let UserData = await (0,_config_db__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)("delete from users where user_id=?", [id]); // if (UserData.length > 0) res.status(200).json('User');
    // else {
    //   next(
    //     new ErrorHandler(` User  doesnt exist in db with id ${id}`, 404)
    //   );
    // }

    res.status(200).json("User Deleted Successfully");
  } catch (err) {
    res.status(500).json(err);
  }
};

const saveMsg = async (req, res) => {
  try {
    let id = 1;
    var msg = req.body.msg;
    let UserData = await (0,_config_db__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)({
      query: `update transmsg set message=? where id=?`,
      values: [msg, id]
    });
    res.status(201).json(UserData);
  } catch (err) {
    console.error(err);
    res.status(400).json(err);
  }
};

const updateMsg = async (req, res) => {
  // let id = req.query.id;
  //console.log("id", id);
  const msg = req.body.msg;
  let id = 1;

  try {
    UserData = await (0,_config_db__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(`update msg set message=? where id=${id}`, [msg]);
    res.status(200).json(UserData);
  } catch (err) {
    res.status(400).json(err);
  }
};



/***/ })

};
;